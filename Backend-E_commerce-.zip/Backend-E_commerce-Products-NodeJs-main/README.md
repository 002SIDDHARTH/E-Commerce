# BackEnd - NodeJs - E_Commerce Products Shop
# Branch MongoDB - Support MongoDB

Frave Developer

### Yotube Channel
[Frave Developer](https://www.youtube.com/channel/UCkNYlmbx487MPmYvfSMAdRg)

### Social Media

<a href="https://www.instagram.com/frave_developer">
    <img src="https://github.com/aritraroy/social-icons/blob/master/instagram-icon.png?raw=true" width="50">
</a>

### Donate

<a href="https://www.buymeacoffee.com/frave">
    <img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" width="200">
</a>

[PayPal](https://www.paypal.me/Fpereza)

### Mysql

- Go to Folder Mysql where you will the script for the creation of Database and the stored procedures

### Nodejs

```sh
    npm install
```

### Running the project

```sh
    npm start
```

## App Flutter

- https://github.com/Frave07/ECommerce-Products-Flutter

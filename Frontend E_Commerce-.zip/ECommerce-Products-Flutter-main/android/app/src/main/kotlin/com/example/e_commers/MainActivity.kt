package com.example.e_commers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

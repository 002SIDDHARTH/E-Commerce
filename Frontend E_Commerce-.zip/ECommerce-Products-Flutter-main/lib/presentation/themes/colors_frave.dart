import 'package:flutter/material.dart' show Color;

class ColorsFrave {

  static const Color primaryColorFrave = Color(0xFF0657C8);
  static const Color secundaryColorFrave = Color(0xff002C8B);
  static const Color backgroundColorFrave = Color(0xff21242C);

}
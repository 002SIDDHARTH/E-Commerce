
class Environment {

  static const String baseUrl = 'http://192.168.0.104:7070/';
  
  static const String urlApi = 'http://192.168.0.104:7070/api';

}